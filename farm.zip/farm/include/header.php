<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Aami Shetkari</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f8f9fa;
    }
    .header {
      background: linear-gradient(to right, #c1a8a8, #81C784);
      color: white;
      padding: 40px 20px;
      text-align: center;
      border-radius: 0 0 20px 20px;
    }
    .custom-navbar {
      background-color: #4CAF50;
    }
    .navbar-brand, .nav-link {
      color: white !important;
    }
    .card.rounded-4 {
      border-radius: 1rem;
    }
    .mobile-nav {
      display: flex;
      justify-content: space-around;
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      background: #4CAF50;
      padding: 10px 0;
      z-index: 1000;
    }
    .mobile-nav a {
      color: white;
      text-decoration: none;
      font-size: 13px;
      text-align: center;
      flex: 1;
    }
    .mobile-nav a span {
      font-size: 20px;
      display: block;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg sticky-top shadow custom-navbar-dark">
  <div class="container-fluid" style="background-color: black;">
    <a class="navbar-brand d-flex align-items-center text-white" href="#" style="font-size:1.5em;font-weight:700;letter-spacing:1px;">
      <span style="font-size:1.6em;margin-right:8px;">🌾</span>
      <span class="brand-gradient-text">Aami Shetkari</span>
    </a>
    <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
      aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link nav-ani text-white" href="add_expense.php">Expenses</a></li>
        <li class="nav-item"><a class="nav-link nav-ani text-white" href="add_income.php">Income</a></li>
        <li class="nav-item"><a class="nav-link nav-ani text-white" href="report.php">Reports</a></li>
        <li class="nav-item"><a class="nav-link nav-ani text-white" href="#">Profile</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Mobile Nav -->
<nav class="mobile-nav d-lg-none" style="background-color: black;">
  <a href="index.php"><span>🏠</span>Home</a>
  <a href="add_expense.php"><span>💸</span>Expenses</a>
  <a href="add_income.php"><span>📥</span>Income</a>
  <a href="report.php"><span>📊</span>Reports</a>
  <a href="#"><span>📈</span>Profit</a>
</nav>
