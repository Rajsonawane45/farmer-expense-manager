<!-- Footer -->
<footer class="text-center mt-5 mb-4 text-muted">
  © 2025 Aami Shetkari | Made with 🌱 for our Farmers
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
